/*
 * File:   message_handler.c
 * Author: satsu
 *
 * Created on 9 March, 2026, 4:04 PM
 */

#include <xc.h>
#include <string.h>
#include "massage_handler.h"
#include "msg_id.h"
#include "can.h"
#include "clcd.h"
#define _XTAL_FREQ 20000000

volatile unsigned char led_state = LED_OFF, status = e_ind_off;

unsigned int delay = 0;

 uint16_t msg_id;
 unsigned char data[5],len;
    
    
void handle_speed_data(uint8_t *data, uint8_t len)
{
    //Implement the speed function
   data[len]='\0';
    if(len>0)
    {
        clcd_putch(data[0],LINE2(0));
        clcd_putch(data[1],LINE2(1));
    }
    else
    {
        clcd_print("not",LINE2(0));
    }
    
}

void handle_gear_data(uint8_t *data, uint8_t len) 
{
    char gear[8][3] = {"G1","G2","G3","G4","G5","RE","NU","CO"};
    //Implement the gear function
    if(len>0)
    {
        clcd_putch(gear[data[0]][0],LINE2(3));
        clcd_putch(gear[data[0]][1],LINE2(4));
    }
    else
    {
        clcd_print("GEAR",LINE2(3));
    }
}

void handle_rpm_data(uint8_t *data, uint8_t len) 
{
    //Implement the rpm function
    if(len>0)
    {
        clcd_putch(data[0],LINE2(6));
        clcd_putch(data[1],LINE2(7));
        clcd_putch(data[2],LINE2(8));
        clcd_putch(data[3],LINE2(9));
    }
    else
    {
        clcd_print("not",LINE2(6));
    }
}

void handle_engine_temp_data(uint8_t *data, uint8_t len) 
{
    //Implement the temperature function
  //  clcd_putch(data[0],LINE2(3));
   // clcd_putch(data[1],LINE2(4));
}
volatile uint8_t ind = 0;
void handle_indicator_data(uint8_t *data, uint8_t len) 
{
    //Implement the indicator function
    ind = data[0];
    if(len>0)
    {
        if(ind == 1)   //left
        {
            if(delay++ < 500)
            {
                RB0 = !RB0;
                RB1 = !RB1;
                RB6 = 0;
                RB7 = 0;
            }
            else if(delay < 1000)
            {
                PORTB = 0x00;
            }
            else
            {
                delay = 0;
            }
            clcd_putch('<',LINE2(11));
            clcd_putch('-',LINE2(12));
            clcd_putch('L',LINE2(13));
            clcd_putch('T',LINE2(14));
          
        }
        else if(ind == 2)  // right
        {
             if(delay++ < 500)
            {
                RB0 = 0;
                RB1 = 0;
                RB6 = !RB6;
                RB7 = !RB7;
            }
            else if(delay < 1000)
            {
                PORTB = 0x00;
            }
            else
            {
                delay = 0;
            }
            clcd_putch('-',LINE2(11));
            clcd_putch('>',LINE2(12));
            clcd_putch('R',LINE2(13));
            clcd_putch('T',LINE2(14));
            
        }
        else if(ind == 3)  // hazard
        {
             if(delay++ < 500)
            {
                RB0 = !RB0;
                RB1 = !RB1;
                RB6 = !RB6;
                RB7 = !RB7;
            }
            else if(delay < 1000)
            {
                PORTB = 0x00;
            }
            else
            {
                delay = 0;
            }
            clcd_putch('H',LINE2(11));
            clcd_putch('Z',LINE2(12));
            clcd_putch(' ',LINE2(13));
            clcd_putch(' ',LINE2(14));
            
        }
        else if(ind == 0)//off
        {
            PORTB = 0x00;
            clcd_putch('O',LINE2(11));
            clcd_putch('F',LINE2(12));
            clcd_putch(' ',LINE2(13));
            clcd_putch(' ',LINE2(14));
        }
    }
    else
    {
        clcd_print("Not",LINE2(11));
    }
}

void process_canbus_data() 
{   
    //__delay_ms(200);
    if(PIR3bits.RXB0IF)  
    {
    //process the CAN bus data
       can_receive(&msg_id,data,&len);
    
    //__delay_ms(200);
    
            if(msg_id == SPEED_MSG_ID)
            {
                handle_speed_data(data,len);
            }
            
            if(msg_id == GEAR_MSG_ID)
            {
                
                handle_gear_data(data,len);
            }
            if(msg_id == RPM_MSG_ID)
            {
                
                handle_rpm_data(data,len);
            }
            if(msg_id == INDICATOR_MSG_ID)
            {
                handle_indicator_data(data,len);
            }
            if(msg_id == ENG_TEMP_MSG_ID)
            {
                handle_engine_temp_data(data,len);
            }
    }
    
}