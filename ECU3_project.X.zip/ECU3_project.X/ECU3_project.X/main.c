/*
 * File:   main.c
 * Author: satsu
 *
 * Created on 9 March, 2026, 4:05 PM
 */


#include <xc.h>
#include <stdint.h>
#include "can.h"
#include "clcd.h"
#include "msg_id.h"
#include "massage_handler.h"


static void init_leds() 
{
    TRISB = 0x00; // Set RB2 as output, RB3 as input, remaining as output
    PORTB = 0x00;
}

static void init_config(void) {
    // Initialize CLCD and CANBUS
    init_clcd();
    init_leds();
    init_can();
    

}

void main(void) {
    // Initialize peripherals
    init_config();

    /* ECU1 main loop */
    clcd_print("SP GR RPM IN",LINE1(0));
    while(1) 
    {
        // Read CAN Bus data and handle it
        process_canbus_data();
    }

    return;
}



