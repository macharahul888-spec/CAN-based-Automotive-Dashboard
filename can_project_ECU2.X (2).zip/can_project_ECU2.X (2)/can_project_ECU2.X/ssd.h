/* 
 * File:   ssd.h
 * Author: Rahul.M
 *
 * Created on 03 April, 2026, 3:48 PM
 */

#ifndef SSD_H
#define	SSD_H


#define DATA_PORT  PORTD
#define CONTROL_PORT PORTA

#define DATA_PORT_DDR TRISD
#define CONTROL_PORT_DDR TRISA

void init_ssd(void);
void display(unsigned char* SSD);  //(uint8_t *SSD)

#endif	/* SSD_H */
