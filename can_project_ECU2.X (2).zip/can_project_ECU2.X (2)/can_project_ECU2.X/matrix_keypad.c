/*
 * File:   matrix_keypad.c
 * Author: Rahul.M
 *
 * Created on 03 April, 2026, 3:54 PM
 */


#include <xc.h>
#include "matrix_keypad.h"

void init_matrix_keypad()
{
    RBPU = 0;    //setting portb as pull up register
    
    TRISB = TRISB & 0X1F;          //setting RB7-RB5 as outputs
    
    TRISB = TRISB | 0X1E;         //setting RB1-RB4 AS inputs
    
    PORTB = PORTB | 0XE0;         //setting first three pins as 1
} 

unsigned char scan_key(void)
{
    //CHECK ROW 1
    RW1 = 0;   
    RW2 = RW3 = 1;
    
    if(COL1 == 0)
        return SW1;
    else if(COL2 == 0)
        return SW4;
    else if(COL3 == 0)
        return SW7;
    else if(COL4 == 0)
        return SW10;
    
    //CHECK ROW 2
    RW2 = 0;
    RW1 = RW3 = 1;
    
    if(COL1 == 0)
        return SW2;
    else if(COL2 == 0)
        return SW5;
    else if(COL3 == 0)
        return SW8;
    else if(COL4 == 0)
        return SW11;
    
    //CHECK ROW 3
    RW3 = 0;
    RW1 = RW2 = 1;
    
    if(COL1 == 0)
        return SW3;
    else if(COL2 == 0)
        return SW6;
    else if(COL3 == 0)
        return SW9;
    else if(COL4 == 0)
        return SW12;
    
    return 0XFF;      //NO ANY SWITCH IS PRESSED
}


unsigned char read_matrix_keypad(unsigned char triggering_method)
{
    static unsigned char once = 1;
    if(triggering_method == LEVEL)
    {
        return  scan_key();
    }
    else if(triggering_method == EDGE)
    {
        unsigned char key = scan_key();
        
        if((key != 0XFF) && (once == 1))
        {
            once = 0;
            return key;
        }
        else if(key == 0XFF)         //all switch released
        {
            once = 1;
        }
     
    }
       return 0XFF;      //nothing is pressed
}